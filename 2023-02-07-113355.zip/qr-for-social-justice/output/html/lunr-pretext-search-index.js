var ptx_lunr_search_style = "textbook";
var ptx_lunr_docs = [
{
  "id": "colophon-1",
  "level": "1",
  "url": "colophon-1.html",
  "type": "Colophon",
  "number": "",
  "title": "Colophon",
  "body": "  kenanince.org  http:\/\/kenanince.org   copyright  "
},
{
  "id": "dedication-1",
  "level": "1",
  "url": "dedication-1.html",
  "type": "Dedication",
  "number": "",
  "title": "Dedication",
  "body": " For ...  "
},
{
  "id": "acknowledgement-1",
  "level": "1",
  "url": "acknowledgement-1.html",
  "type": "Acknowledgements",
  "number": "",
  "title": "Acknowledgements",
  "body": " We would like to thank our colleagues at Westminster who have encouraged interdisciplinary and justice-minded thinking, every educator doing this work, and especially the activists and K-12 educators who have blazed the trail of social justice math for decades.  "
},
{
  "id": "preface",
  "level": "1",
  "url": "preface.html",
  "type": "Preface",
  "number": "",
  "title": "Preface",
  "body": "   This workbook is designed to be used as the primary text for a course on quantitative reasoning with a particular focus on social and political issues. We encourage you to implement the chapters as modules in any relevant course--see   A Crash Course: Incorporating Social Justice into Postsecondary Math     Welcome to the workbook! I hope it is helpful to you. I believe this is the first attempt to collect together resources for a quantitative reasoning course framed around social justice (specifically targeted at higher-ed math faculty) as possible. I am indebted to and model my work after the K-12 educators (e.g. Bob Moses, Jonathan Osler) who have been doing this work for decades.        Getting Started   If you’re new to incorporating social justice issues into math classes, I’d encourage you to start by reading or skimming Jonathan Osler’s “A Guide for Integrating Issues of Social and Economic Justice into Mathematics Curriculum” , made by a high-school educator but equally relevant in the postsecondary context. Next, Drew Winter’s “Infusing Mathematics with Culture” offers a valuable framework for thinking about the relationship between mathematical content and social justice issues, as well as an emphasis on connecting to student activism and interests.  This book is meant to be used as a workbook for students in a quantitative reasoning (QR) course framed around issues of social justice (SJ). This course developed out of my resource folder for open-access SJ math resources ; feel free to mix and match chapters from this book and resources from the folder to plug into existing courses as well as to \"remix\" your own full course.    Why Teach Postsecondary Math for Social Justice?    Culturally relevant teaching practices contribute to educational equity and social justice (McGee 2014)  Teaching math with a social justice frame increases student learning and achievement (Gutstein 2003; Moses & Cobb 2001; Winter 2007)  Math is already political. What assumptions do our algorithms and databases inherit (O'Neill 2016)? What do we think is \"worthy\" of mathematical inquiry? Math with applications to petroleum engineering or fracking (Hendrickson 2015) ? Statistical analyses of police stops by race (Khadjavi 2013 , Ince 2021 )?  See this literature review (Ince 2015) for an investigation of what the research shows about teaching math for social justice.    Other Texts for a Math for Social Justice Course  Resources are beginning to be developed for full postsecondary courses, largely in quantitative reasoning, for social justice. A few of the exciting new resources are described in the table below; please fill out this form if you know of any postsecondary-level resources I’m missing!   Texts for a Semester Course on Social Justice Math    Resource Type  Authors  Name and Links to Resource(s)  Cost    Complete lesson plan collections  Gizem Karaali, Lily Khadjavi  Mathematics for Social Justice and Focusing on Quantitative Reasoning and Statistics  ~$60 each    Lesson plan collection in development  Mark Branson, Whitney George  Math for the People  Free    Complete PDF book; not always SJ-focused  David Lippman  Math in Society  Free       After the last subsection, you might have a conclusion.     Example SJ Math Activities for the First Day  Here are some examples of questions I've asked my students, almost always in a think-pair-share format, to start off a semester-long course on quantitative reasoning for social justice:   What do you think of when you think of social justice? What are 2-3 issues of SJ you're passionate about? Can we develop a working definition of SJ as a class?    Some possible answers: justice in terms of the distribution of wealth, opportunities, and privileges within a society. (Google Dictionary)  a concept of fair and just relations between the individual and society. (Wikipedia)  a state or doctrine of egalitarianism (Merriam-Webster)  A broad term for action intended to create genuine equality, fairness and respect among peoples. (University of Massachusetts Lowell Department of Multicultural Affairs)     One working definition that my classes have used (due to Sensoy-DiAngelo) is the following. Social justice is a recognition that:  all people are individuals, but we are also members of socially constructed groups;  society is stratified, and social groups are valued unequally;  social groups that are valued more highly have greater access to resources and this access is structured into the institutions and cultural norms;  social injustice is real and exists today;  relations of unequal power are constantly being enacted at both the micro (individual) and macro (structural) levels;  we are all socialized to be complicit in these relations;  those who claim to be for social justice must strategically act from that claim in ways that challenge social injustice; and  this action requires a commitment to an ongoing and lifelong process.    Here are some more examples I've used in courses during the COVID-19 pandemic:   A first-day activity for a pandemic   What are some social justice issues that are important to you in the midst of rising inequality and authoritarianism, climate crisis, racial justice movements, and more?  What are some ways we could measure each of these issues? (how bad they are, solutions, societal reactions, etc.)  What are some things you don't know how to measure about each of these issues?  Estimate: what are some strategies for measuring these things? Don't try to plug in numbers yet, just make a list.  What are some ways to, as accurately as possible, measure how severe the COVID-19 outbreak is in your city? Write down any assumptions you make about what “severe” means.  If you were a disability rights activist concerned about the dangers of COVID-19 for immunocompromised folks, which of these ways would you choose to measure? Estimate or find the info.  If you were an administrator at your college or university, which of these ways would you choose to measure? Explain, then estimate or find the info.  What are some things it would be ideal to be able to measure in order to curtail or prevent the spread of COVID-19 in your city? Do the same as above: how would you measure these things as a disability rights activist? As a college administrator?  Brainstorm some ways to obtain the measurements you described above. If you obtained these measurements, how could you use them to advocate for positive change?  What questions about social justice, health\/accessibility, and math does this activity bring up for you?   You may have come up with questions similar to the following:  How did we measure X?  What's the best way to measure X?  What values are inherent in the way we measure X?  If your goal is to advocate for social justice, how does that change the “best” way of measuring X?    We just demonstrated a couple of tools we'll use many times in the next week or two:  Estimation : round up or down to make calculations easier and numbers less messy. As we saw when estimating the number of classrooms needed for the US household wealth, rounding before the computation ends can introduce error. Therefore, if you have a calculator, it's best to plug into the calculator before rounding, whereas if you're computing by hand, rounding may be necessary in order to increase the accuracy of your computations. Everyone makes arithmetic mistakes–you'll see me do it plenty of times!  Dimensional analysis : start with the given and multiply by fractions, canceling out the units, until you get something in the units your answer should be in. This is almost always your answer!      This activity is almost directly adapted from Dana Ernst's \"Setting the Stage\" inquiry-based learning activity. Get in groups of size 3–4. Group members should introduce themselves - name, pronouns, hobbies outside school, goals for the semester\/year, reason they're taking the course. For each of the questions that follow, I will ask you to:  Think about a possible answer on your own.  Discuss your answers with the rest of your group.  Share a summary of each group’s discussion.  The questions are as follows:  What are the goals of a college or university education? How does social justice fit in? How does math?  How does a person learn something new?  What is the value of making mistakes in the learning process?  How do we create a safe environment where risk taking is encouraged and productive failure is valued?    As Ernst describes on his website , Each time I’ve run the activity, the responses are slightly different. The responses to the first two questions are usually what you would expect. Question 3 always generates great discussions. The idea of “productive failure” naturally arises when discussing question 4 and I provide them with this language sometime while discussing this question. Listening to the students’ responses to question 4 is awesome. It’s really nice to get the students establishing the necessary culture of the class without me having to tell them what to do.  After we are done discussing the 5 questions, I elaborate on the importance of productive failure and inform that I will often tag things in class with the hashtag #pf in an attempt to emphasize its value. I also provide them with the following quote from Mike Starbird: “Any creative endeavor is built on the ash heap of failure.” I wrap up the activity by conveying some claims I make about education and stating some of my goals as a teacher.  Claims   An education must prepare a student to ask and explore questions in contexts that do not yet exist. That is, we need individuals capable of tackling problems they have never encountered and to ask questions no one has yet thought of.  If we really want students to be independent, inquisitive, & persistent, then we need to provide them with the means to acquire these skills.        Group work and class norms   Ground rules  Given the nature of this course, it’s important that we develop class norms to promote an atmosphere which will facilitate the learning process as well as respect the experiences of different groups in the classroom and the larger society. The class can agree to revise them and add others, but all students must commit themselves to the final set of rules by the end of the first class. These principles will guide our class discussions and interactions.  Think-Pair-Share on what common norms for group work and discussion are important for our class.    Whose voices are valued?    What philosophy do we have about who can make contributions to mathematics and the value of those contributions?    How does this connect to the values we espouse for our democracy?     Here are some useful classroom norms:     Controversy and vulnerability : different views are expected and honored with a group commitment to understand the sources of disagreement and to work cooperatively toward common solutions without putting a disproportionate responsibility on marginalized groups to educate us .    No one’s identities are under question: e.g. no arguing that queer people are wrong for existing.    Please come talk to your instructor anytime you feel uncomfortable enough that it’s affecting your work in class.       Own your intentions and your impact. Acknowledge that the impact of your actions is not always congruent with your intentions and that positive or neutral intentions do not trump negative impact. Participate truthfully and accept when your actions or words harm others.     Challenge by choice : individuals may determine for themselves if and to what degree they will participate in a given discussion or activity. It is possible not to participate in a few activities and still receive an A in the course. Be aware of what factors influence your decision about whether to challenge yourself on a given issue.     Respect : each other and yourselves. Investigate how your cultural context affects what you think of as respect for others and acknowledge what respect looks like in other contexts.     No attacks . personal attacks are a form of extreme disrespect. Disagreeing with ideas is welcome; attacking individuals for their ideas is not.      (TPS) What does respect look like for you? How might ideas of respect vary with cultural context? How might you firmly challenge the views of someone else in a respectful manner?   What are the differences betweeen a personal attack and a challenge to an idea that makes an individual feel uncomfortable? What are some situations that might blur the lines between the two? How can we acknowledge when certain beliefs (e.g. trans people not existing) are inherently personal attacks?        Group roles : In order to facilitate group interaction, you will take on group roles designed to mimic the role of mathematical and\/or sociological researchers. The roles are as follows:     The facilitator is responsible for making sure every student is able to contribute and be heard. Contributions may include asking good questions, rephrasing someone else’s idea, coming up with a way of connecting mathematics to the real world, and many others.    the resource manager is responsible for obtaining and keeping track of all necessary resources to solve a problem. Resources may include writing utensils, paper, the Internet, your instructor, data sources, and most importantly, your team.    the lead author is responsible for writing down the ideas that each group comes up with.    the communicator is responsible for reporting what your group came up with to the class, instructor, and any relevant community groups.    Assign roles to each group by first letters of first name; they’ll rotate every day of class. Anyone can answer questions posed to the whole class, but if your group came up with an idea that hasn’t been shared yet, it someone in your group’s responsibility to share your answer so that everyone can learn from you!    Reconsider the question from the beginning of class: do you think of when you think of social justice? How has your answer changed over the course of our discussion?         "
},
{
  "id": "p-3",
  "level": "2",
  "url": "preface.html#p-3",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Controversy and vulnerability without putting a disproportionate responsibility on marginalized groups to educate us Own your intentions and your impact. Challenge by choice Respect No attacks Group roles The facilitator resource manager lead author communicator "
},
{
  "id": "sec_crashcourse-intro",
  "level": "1",
  "url": "sec_crashcourse-intro.html",
  "type": "Section",
  "number": "2.1",
  "title": "Getting Started",
  "body": " Getting Started   If you’re new to incorporating social justice issues into math classes, I’d encourage you to start by reading or skimming Jonathan Osler’s “A Guide for Integrating Issues of Social and Economic Justice into Mathematics Curriculum” , made by a high-school educator but equally relevant in the postsecondary context. Next, Drew Winter’s “Infusing Mathematics with Culture” offers a valuable framework for thinking about the relationship between mathematical content and social justice issues, as well as an emphasis on connecting to student activism and interests.  This book is meant to be used as a workbook for students in a quantitative reasoning (QR) course framed around issues of social justice (SJ). This course developed out of my resource folder for open-access SJ math resources ; feel free to mix and match chapters from this book and resources from the folder to plug into existing courses as well as to \"remix\" your own full course.    Why Teach Postsecondary Math for Social Justice?    Culturally relevant teaching practices contribute to educational equity and social justice (McGee 2014)  Teaching math with a social justice frame increases student learning and achievement (Gutstein 2003; Moses & Cobb 2001; Winter 2007)  Math is already political. What assumptions do our algorithms and databases inherit (O'Neill 2016)? What do we think is \"worthy\" of mathematical inquiry? Math with applications to petroleum engineering or fracking (Hendrickson 2015) ? Statistical analyses of police stops by race (Khadjavi 2013 , Ince 2021 )?  See this literature review (Ince 2015) for an investigation of what the research shows about teaching math for social justice.    Other Texts for a Math for Social Justice Course  Resources are beginning to be developed for full postsecondary courses, largely in quantitative reasoning, for social justice. A few of the exciting new resources are described in the table below; please fill out this form if you know of any postsecondary-level resources I’m missing!   Texts for a Semester Course on Social Justice Math    Resource Type  Authors  Name and Links to Resource(s)  Cost    Complete lesson plan collections  Gizem Karaali, Lily Khadjavi  Mathematics for Social Justice and Focusing on Quantitative Reasoning and Statistics  ~$60 each    Lesson plan collection in development  Mark Branson, Whitney George  Math for the People  Free    Complete PDF book; not always SJ-focused  David Lippman  Math in Society  Free       After the last subsection, you might have a conclusion.   "
},
{
  "id": "table-2",
  "level": "2",
  "url": "sec_crashcourse-intro.html#table-2",
  "type": "Table",
  "number": "2.1.1",
  "title": "Texts for a Semester Course on Social Justice Math",
  "body": " Texts for a Semester Course on Social Justice Math    Resource Type  Authors  Name and Links to Resource(s)  Cost    Complete lesson plan collections  Gizem Karaali, Lily Khadjavi  Mathematics for Social Justice and Focusing on Quantitative Reasoning and Statistics  ~$60 each    Lesson plan collection in development  Mark Branson, Whitney George  Math for the People  Free    Complete PDF book; not always SJ-focused  David Lippman  Math in Society  Free    "
},
{
  "id": "sec_firstch-examples",
  "level": "1",
  "url": "sec_firstch-examples.html",
  "type": "Section",
  "number": "2.2",
  "title": "Example SJ Math Activities for the First Day",
  "body": " Example SJ Math Activities for the First Day  Here are some examples of questions I've asked my students, almost always in a think-pair-share format, to start off a semester-long course on quantitative reasoning for social justice:   What do you think of when you think of social justice? What are 2-3 issues of SJ you're passionate about? Can we develop a working definition of SJ as a class?    Some possible answers: justice in terms of the distribution of wealth, opportunities, and privileges within a society. (Google Dictionary)  a concept of fair and just relations between the individual and society. (Wikipedia)  a state or doctrine of egalitarianism (Merriam-Webster)  A broad term for action intended to create genuine equality, fairness and respect among peoples. (University of Massachusetts Lowell Department of Multicultural Affairs)     One working definition that my classes have used (due to Sensoy-DiAngelo) is the following. Social justice is a recognition that:  all people are individuals, but we are also members of socially constructed groups;  society is stratified, and social groups are valued unequally;  social groups that are valued more highly have greater access to resources and this access is structured into the institutions and cultural norms;  social injustice is real and exists today;  relations of unequal power are constantly being enacted at both the micro (individual) and macro (structural) levels;  we are all socialized to be complicit in these relations;  those who claim to be for social justice must strategically act from that claim in ways that challenge social injustice; and  this action requires a commitment to an ongoing and lifelong process.    Here are some more examples I've used in courses during the COVID-19 pandemic:   A first-day activity for a pandemic   What are some social justice issues that are important to you in the midst of rising inequality and authoritarianism, climate crisis, racial justice movements, and more?  What are some ways we could measure each of these issues? (how bad they are, solutions, societal reactions, etc.)  What are some things you don't know how to measure about each of these issues?  Estimate: what are some strategies for measuring these things? Don't try to plug in numbers yet, just make a list.  What are some ways to, as accurately as possible, measure how severe the COVID-19 outbreak is in your city? Write down any assumptions you make about what “severe” means.  If you were a disability rights activist concerned about the dangers of COVID-19 for immunocompromised folks, which of these ways would you choose to measure? Estimate or find the info.  If you were an administrator at your college or university, which of these ways would you choose to measure? Explain, then estimate or find the info.  What are some things it would be ideal to be able to measure in order to curtail or prevent the spread of COVID-19 in your city? Do the same as above: how would you measure these things as a disability rights activist? As a college administrator?  Brainstorm some ways to obtain the measurements you described above. If you obtained these measurements, how could you use them to advocate for positive change?  What questions about social justice, health\/accessibility, and math does this activity bring up for you?   You may have come up with questions similar to the following:  How did we measure X?  What's the best way to measure X?  What values are inherent in the way we measure X?  If your goal is to advocate for social justice, how does that change the “best” way of measuring X?    We just demonstrated a couple of tools we'll use many times in the next week or two:  Estimation : round up or down to make calculations easier and numbers less messy. As we saw when estimating the number of classrooms needed for the US household wealth, rounding before the computation ends can introduce error. Therefore, if you have a calculator, it's best to plug into the calculator before rounding, whereas if you're computing by hand, rounding may be necessary in order to increase the accuracy of your computations. Everyone makes arithmetic mistakes–you'll see me do it plenty of times!  Dimensional analysis : start with the given and multiply by fractions, canceling out the units, until you get something in the units your answer should be in. This is almost always your answer!      This activity is almost directly adapted from Dana Ernst's \"Setting the Stage\" inquiry-based learning activity. Get in groups of size 3–4. Group members should introduce themselves - name, pronouns, hobbies outside school, goals for the semester\/year, reason they're taking the course. For each of the questions that follow, I will ask you to:  Think about a possible answer on your own.  Discuss your answers with the rest of your group.  Share a summary of each group’s discussion.  The questions are as follows:  What are the goals of a college or university education? How does social justice fit in? How does math?  How does a person learn something new?  What is the value of making mistakes in the learning process?  How do we create a safe environment where risk taking is encouraged and productive failure is valued?    As Ernst describes on his website , Each time I’ve run the activity, the responses are slightly different. The responses to the first two questions are usually what you would expect. Question 3 always generates great discussions. The idea of “productive failure” naturally arises when discussing question 4 and I provide them with this language sometime while discussing this question. Listening to the students’ responses to question 4 is awesome. It’s really nice to get the students establishing the necessary culture of the class without me having to tell them what to do.  After we are done discussing the 5 questions, I elaborate on the importance of productive failure and inform that I will often tag things in class with the hashtag #pf in an attempt to emphasize its value. I also provide them with the following quote from Mike Starbird: “Any creative endeavor is built on the ash heap of failure.” I wrap up the activity by conveying some claims I make about education and stating some of my goals as a teacher.  Claims   An education must prepare a student to ask and explore questions in contexts that do not yet exist. That is, we need individuals capable of tackling problems they have never encountered and to ask questions no one has yet thought of.  If we really want students to be independent, inquisitive, & persistent, then we need to provide them with the means to acquire these skills.        Group work and class norms   Ground rules  Given the nature of this course, it’s important that we develop class norms to promote an atmosphere which will facilitate the learning process as well as respect the experiences of different groups in the classroom and the larger society. The class can agree to revise them and add others, but all students must commit themselves to the final set of rules by the end of the first class. These principles will guide our class discussions and interactions.  Think-Pair-Share on what common norms for group work and discussion are important for our class.    Whose voices are valued?    What philosophy do we have about who can make contributions to mathematics and the value of those contributions?    How does this connect to the values we espouse for our democracy?     Here are some useful classroom norms:     Controversy and vulnerability : different views are expected and honored with a group commitment to understand the sources of disagreement and to work cooperatively toward common solutions without putting a disproportionate responsibility on marginalized groups to educate us .    No one’s identities are under question: e.g. no arguing that queer people are wrong for existing.    Please come talk to your instructor anytime you feel uncomfortable enough that it’s affecting your work in class.       Own your intentions and your impact. Acknowledge that the impact of your actions is not always congruent with your intentions and that positive or neutral intentions do not trump negative impact. Participate truthfully and accept when your actions or words harm others.     Challenge by choice : individuals may determine for themselves if and to what degree they will participate in a given discussion or activity. It is possible not to participate in a few activities and still receive an A in the course. Be aware of what factors influence your decision about whether to challenge yourself on a given issue.     Respect : each other and yourselves. Investigate how your cultural context affects what you think of as respect for others and acknowledge what respect looks like in other contexts.     No attacks . personal attacks are a form of extreme disrespect. Disagreeing with ideas is welcome; attacking individuals for their ideas is not.      (TPS) What does respect look like for you? How might ideas of respect vary with cultural context? How might you firmly challenge the views of someone else in a respectful manner?   What are the differences betweeen a personal attack and a challenge to an idea that makes an individual feel uncomfortable? What are some situations that might blur the lines between the two? How can we acknowledge when certain beliefs (e.g. trans people not existing) are inherently personal attacks?        Group roles : In order to facilitate group interaction, you will take on group roles designed to mimic the role of mathematical and\/or sociological researchers. The roles are as follows:     The facilitator is responsible for making sure every student is able to contribute and be heard. Contributions may include asking good questions, rephrasing someone else’s idea, coming up with a way of connecting mathematics to the real world, and many others.    the resource manager is responsible for obtaining and keeping track of all necessary resources to solve a problem. Resources may include writing utensils, paper, the Internet, your instructor, data sources, and most importantly, your team.    the lead author is responsible for writing down the ideas that each group comes up with.    the communicator is responsible for reporting what your group came up with to the class, instructor, and any relevant community groups.    Assign roles to each group by first letters of first name; they’ll rotate every day of class. Anyone can answer questions posed to the whole class, but if your group came up with an idea that hasn’t been shared yet, it someone in your group’s responsibility to share your answer so that everyone can learn from you!    Reconsider the question from the beginning of class: do you think of when you think of social justice? How has your answer changed over the course of our discussion?    "
},
{
  "id": "exercise-7",
  "level": "2",
  "url": "sec_firstch-examples.html#exercise-7",
  "type": "Checkpoint",
  "number": "2.2.1",
  "title": "",
  "body": " What do you think of when you think of social justice? What are 2-3 issues of SJ you're passionate about? Can we develop a working definition of SJ as a class?    Some possible answers: justice in terms of the distribution of wealth, opportunities, and privileges within a society. (Google Dictionary)  a concept of fair and just relations between the individual and society. (Wikipedia)  a state or doctrine of egalitarianism (Merriam-Webster)  A broad term for action intended to create genuine equality, fairness and respect among peoples. (University of Massachusetts Lowell Department of Multicultural Affairs)    "
},
{
  "id": "example-3",
  "level": "2",
  "url": "sec_firstch-examples.html#example-3",
  "type": "Example",
  "number": "2.2.2",
  "title": "",
  "body": " A first-day activity for a pandemic   What are some social justice issues that are important to you in the midst of rising inequality and authoritarianism, climate crisis, racial justice movements, and more?  What are some ways we could measure each of these issues? (how bad they are, solutions, societal reactions, etc.)  What are some things you don't know how to measure about each of these issues?  Estimate: what are some strategies for measuring these things? Don't try to plug in numbers yet, just make a list.  What are some ways to, as accurately as possible, measure how severe the COVID-19 outbreak is in your city? Write down any assumptions you make about what “severe” means.  If you were a disability rights activist concerned about the dangers of COVID-19 for immunocompromised folks, which of these ways would you choose to measure? Estimate or find the info.  If you were an administrator at your college or university, which of these ways would you choose to measure? Explain, then estimate or find the info.  What are some things it would be ideal to be able to measure in order to curtail or prevent the spread of COVID-19 in your city? Do the same as above: how would you measure these things as a disability rights activist? As a college administrator?  Brainstorm some ways to obtain the measurements you described above. If you obtained these measurements, how could you use them to advocate for positive change?  What questions about social justice, health\/accessibility, and math does this activity bring up for you?   You may have come up with questions similar to the following:  How did we measure X?  What's the best way to measure X?  What values are inherent in the way we measure X?  If your goal is to advocate for social justice, how does that change the “best” way of measuring X?    We just demonstrated a couple of tools we'll use many times in the next week or two:  Estimation : round up or down to make calculations easier and numbers less messy. As we saw when estimating the number of classrooms needed for the US household wealth, rounding before the computation ends can introduce error. Therefore, if you have a calculator, it's best to plug into the calculator before rounding, whereas if you're computing by hand, rounding may be necessary in order to increase the accuracy of your computations. Everyone makes arithmetic mistakes–you'll see me do it plenty of times!  Dimensional analysis : start with the given and multiply by fractions, canceling out the units, until you get something in the units your answer should be in. This is almost always your answer!    "
},
{
  "id": "example-4",
  "level": "2",
  "url": "sec_firstch-examples.html#example-4",
  "type": "Example",
  "number": "2.2.3",
  "title": "",
  "body": " This activity is almost directly adapted from Dana Ernst's \"Setting the Stage\" inquiry-based learning activity. Get in groups of size 3–4. Group members should introduce themselves - name, pronouns, hobbies outside school, goals for the semester\/year, reason they're taking the course. For each of the questions that follow, I will ask you to:  Think about a possible answer on your own.  Discuss your answers with the rest of your group.  Share a summary of each group’s discussion.  The questions are as follows:  What are the goals of a college or university education? How does social justice fit in? How does math?  How does a person learn something new?  What is the value of making mistakes in the learning process?  How do we create a safe environment where risk taking is encouraged and productive failure is valued?    As Ernst describes on his website , Each time I’ve run the activity, the responses are slightly different. The responses to the first two questions are usually what you would expect. Question 3 always generates great discussions. The idea of “productive failure” naturally arises when discussing question 4 and I provide them with this language sometime while discussing this question. Listening to the students’ responses to question 4 is awesome. It’s really nice to get the students establishing the necessary culture of the class without me having to tell them what to do.  After we are done discussing the 5 questions, I elaborate on the importance of productive failure and inform that I will often tag things in class with the hashtag #pf in an attempt to emphasize its value. I also provide them with the following quote from Mike Starbird: “Any creative endeavor is built on the ash heap of failure.” I wrap up the activity by conveying some claims I make about education and stating some of my goals as a teacher.  Claims   An education must prepare a student to ask and explore questions in contexts that do not yet exist. That is, we need individuals capable of tackling problems they have never encountered and to ask questions no one has yet thought of.  If we really want students to be independent, inquisitive, & persistent, then we need to provide them with the means to acquire these skills.      "
},
{
  "id": "exercise-8",
  "level": "2",
  "url": "sec_firstch-examples.html#exercise-8",
  "type": "Checkpoint",
  "number": "2.2.4",
  "title": "",
  "body": "Think-Pair-Share on what common norms for group work and discussion are important for our class. "
},
{
  "id": "p-75",
  "level": "2",
  "url": "sec_firstch-examples.html#p-75",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Controversy and vulnerability without putting a disproportionate responsibility on marginalized groups to educate us Own your intentions and your impact. Challenge by choice Respect No attacks "
},
{
  "id": "p-86",
  "level": "2",
  "url": "sec_firstch-examples.html#p-86",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Group roles "
},
{
  "id": "p-87",
  "level": "2",
  "url": "sec_firstch-examples.html#p-87",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "The facilitator resource manager lead author communicator "
},
{
  "id": "exercise-11",
  "level": "2",
  "url": "sec_firstch-examples.html#exercise-11",
  "type": "Checkpoint",
  "number": "2.2.5",
  "title": "",
  "body": "Assign roles to each group by first letters of first name; they’ll rotate every day of class. Anyone can answer questions posed to the whole class, but if your group came up with an idea that hasn’t been shared yet, it someone in your group’s responsibility to share your answer so that everyone can learn from you! "
},
{
  "id": "exercise-12",
  "level": "2",
  "url": "sec_firstch-examples.html#exercise-12",
  "type": "Checkpoint",
  "number": "2.2.6",
  "title": "",
  "body": " Reconsider the question from the beginning of class: do you think of when you think of social justice? How has your answer changed over the course of our discussion?  "
},
{
  "id": "solutions-1",
  "level": "1",
  "url": "solutions-1.html",
  "type": "Appendix",
  "number": "A",
  "title": "Selected Hints",
  "body": " Selected Hints  "
},
{
  "id": "solutions-2",
  "level": "1",
  "url": "solutions-2.html",
  "type": "Appendix",
  "number": "B",
  "title": "Selected Solutions",
  "body": " Selected Solutions  "
},
{
  "id": "appendix-1",
  "level": "1",
  "url": "appendix-1.html",
  "type": "Appendix",
  "number": "C",
  "title": "List of Symbols",
  "body": " List of Symbols   "
},
{
  "id": "index-1",
  "level": "1",
  "url": "index-1.html",
  "type": "Index",
  "number": "",
  "title": "Index",
  "body": " Index   "
},
{
  "id": "colophon-2",
  "level": "1",
  "url": "colophon-2.html",
  "type": "Colophon",
  "number": "",
  "title": "Colophon",
  "body": " This book was authored in PreTeXt .  "
}
]

var ptx_lunr_idx = lunr(function () {
  this.ref('id')
  this.field('title')
  this.field('body')

  ptx_lunr_docs.forEach(function (doc) {
    this.add(doc)
  }, this)
})
